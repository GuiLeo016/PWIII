drop database if exists dbLoja;
create database dbLoja;
use dbLoja;

create table if not exists  tbLogin (
	logUsuario varchar(15) primary key not null,
    logSenha varchar(20) not null,
    logNomeUsuario varchar(30) not null,
    logLastUpdate timestamp not null
);

insert into tbLogin (logUsuario, logSenha, logNomeUsuario, logLastUpdate) values
('Guilherme', '1234', 'Guilherme Leonardo', current_timestamp);


create table if not exists tbProdutos (
	cdProduto varchar(5) primary key,
    descProduto varchar(30) not null,
    qtdEstoqProduto decimal(5,2) not null,
    estoqMinProduto decimal(5,2) not null,
    unidadeProduto char(2) not null,
    locacaoProduto varchar(3) not null,
    prcCustoProduto decimal(6,2) not null,
    margLucroProduto decimal(4,2) not null,
    ultAtualizacaoProduto timestamp default current_timestamp on update current_timestamp
);

insert into tbProdutos values ('123', 'Controle Remoto', 0, 5.00, 'Pç', 'A01', 150.00, 10.00, current_timestamp);
insert into tbProdutos values ('222', 'Televisão', 0, 7.00, 'Pç', 'A02', 1700.00, 15.00, current_timestamp);
insert into tbProdutos values ('333', 'Corda', 0, 10.00, 'M', 'B01', 5.00, 5.00, current_timestamp);

create table if not exists tbClientes (
	rgCliente varchar(9) primary key,
    nomeCliente varchar(100) not null,
    enderecoCliente varchar(100) not null,
    cidadeCliente varchar(100) not null,
    ufCliente char(2) not null,
    telefoneCliente varchar(11) not null,
    ultAtualizacao timestamp default current_timestamp on update current_timestamp
);

insert into tbClientes values ('12345678X', 'Gabriel', 'Rua das Flores 777', 'São José dos Campos', 'SP', '12983214257', current_timestamp);

