﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient; //<-- Inserir

namespace prjMinhaLoja
{
    public partial class frmLogin : Form
    {
        // Variáveis de Controle de Conexão

        MySqlConnection conexao;
        MySqlCommand comando;
        MySqlDataAdapter da;
        MySqlDataReader dr;
        string strSQL;

        public frmLogin()
        {
            InitializeComponent();
            //Criando a String de Conexão
            conexao = new MySqlConnection("Server=localhost;Port=3306;Database=dbLoja;User=root");
        }

        private void linkCadastro_Click(object sender, EventArgs e)
        {
            frmCadUsuario frmcadusuario = new frmCadUsuario();
            frmcadusuario.ShowDialog();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            if (txtUsuario.Text == "")
            {
                MessageBox.Show("O campo Nome de Usuário é obrigatório!!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtUsuario.Focus();
                return;
            }
            if (txtSenha.Text == "")
            {
                MessageBox.Show("O campo Senha é obrigatório!!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSenha.Focus();
                return;
            }

            try
            {
                strSQL = "SELECT logSenha FROM tbLogin WHERE logUsuario = @parUsuario";
                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.Clear();
                comando.Parameters.AddWithValue("@parUsuario", txtUsuario.Text);
                conexao.Open();
                comando.ExecuteScalar();
            }
            catch (Exception Erro)
            {
                MessageBox.Show("Erro ==> " + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (comando.ExecuteScalar() == null)
                {
                    MessageBox.Show("Usuário não cadastrado!!", "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    if (Convert.ToString(comando.ExecuteScalar()) != txtSenha.Text)
                    {
                        MessageBox.Show("Senha Incorreta!!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtSenha.Focus();
                    }
                    else
                    {
                        MessageBox.Show("Login Efetuado!!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        this.Visible = false;

                        frmPrincipal frmPrincipal = new frmPrincipal();
                        frmPrincipal.ShowDialog();
                    }
                }
            }
            conexao.Close();
            comando = null;
        }

        private void txtSenha_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (txtUsuario.Text == "")
                {
                    MessageBox.Show("O campo Nome de Usuário é obrigatório!!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtUsuario.Focus();
                    return;
                }
                if (txtSenha.Text == "")
                {
                    MessageBox.Show("O campo Senha é obrigatório!!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtSenha.Focus();
                    return;
                }

                try
                {
                    strSQL = "SELECT logSenha FROM tbLogin WHERE logUsuario = @parUsuario";
                    comando = new MySqlCommand(strSQL, conexao);
                    comando.Parameters.Clear();
                    comando.Parameters.AddWithValue("@parUsuario", txtUsuario.Text);
                    conexao.Open();
                    comando.ExecuteScalar();
                }
                catch (Exception Erro)
                {
                    MessageBox.Show("Erro ==> " + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    if (comando.ExecuteScalar() == null)
                    {
                        MessageBox.Show("Usuário não cadastrado!!", "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        if (Convert.ToString(comando.ExecuteScalar()) != txtSenha.Text)
                        {
                            MessageBox.Show("Senha Incorreta!!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            txtSenha.Focus();
                        }
                        else
                        {
                            MessageBox.Show("Login Efetuado!!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            this.Visible = false;

                            frmPrincipal frmPrincipal = new frmPrincipal();
                            frmPrincipal.ShowDialog();
                        }
                    }
                }
                conexao.Close();
                comando = null;
            }
        }
    }
}
