﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient; //<-- Inserir

namespace prjMinhaLoja
{
    public partial class frmConsProd : Form
    {
        // Variáveis de Controle de Conexão

        MySqlConnection conexao;
        MySqlCommand comando;
        MySqlDataAdapter da;
        MySqlDataReader dr;
        DataTable dt = new DataTable();
        string strSQL;

        public frmConsProd()
        {
            InitializeComponent();
            conexao = new MySqlConnection("Server=localhost;Port=3306;Database=dbLoja;User=root");
        }

        private void frmConsProd_Activated(object sender, EventArgs e)
        {
            txtPesquisar.Focus();

            conexao.Open();
            strSQL = "select * from tbProdutos";
            comando = new MySqlCommand(strSQL, conexao);
            da = new MySqlDataAdapter(comando);
            da.Fill(dt);
            dtGrVwClientes.DataSource = dt;

            dtGrVwClientes.Columns[0].HeaderText = "Codigo";
            dtGrVwClientes.Columns[1].HeaderText = "Descrição";
            dtGrVwClientes.Columns[2].HeaderText = "Estoque";
            dtGrVwClientes.Columns[3].HeaderText = "Estoque Mínimo";
            dtGrVwClientes.Columns[4].HeaderText = "Unidade";
            dtGrVwClientes.Columns[5].HeaderText = "Locação";
            dtGrVwClientes.Columns[6].HeaderText = "Preço";
            dtGrVwClientes.Columns[7].HeaderText = "Margem de Lucro";
            dtGrVwClientes.Columns[8].HeaderText = "Última Atualização";
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPesquisar.Clear();
            txtPesquisar.Focus();

            DataView dv = new DataView(dt);
            dv.RowFilter = string.Format("descProduto like '%{0}%'", txtPesquisar.Text);
            dtGrVwClientes.DataSource = dv;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
            conexao.Close();
        }

        private void txtPesquisar_TextChanged(object sender, EventArgs e)
        {
            DataView dv = new DataView(dt);
            dv.RowFilter = string.Format("descProduto like '%{0}%'", txtPesquisar.Text);
            dtGrVwClientes.DataSource = dv;
        }
    }
}
