﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient; //<-- Inserir

namespace prjMinhaLoja
{
    public partial class frmCadUsuario : Form
    {
        // Variáveis de Controle de Conexão

        MySqlConnection conexao;
        MySqlCommand comando;
        MySqlDataAdapter da;
        MySqlDataReader dr;
        string strSQL;

        public frmCadUsuario()
        {
            InitializeComponent();
            //Criando a String de Conexão
            conexao = new MySqlConnection("Server=localhost;Port=3306;Database=dbLoja;User=root");
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtUsuario.Clear();
            txtSenha.Clear();
            txtNomeUsuario.Clear();
            txtNomeUsuario.ReadOnly = true;
            txtSenha.ReadOnly = true;
            txtUsuario.ReadOnly = false;
            btnCadastrar.Enabled = false;

            toolStripStatusLabel2.Text = "Favor verificar Usuário <Enter>";
            conexao.Close();
            comando = null;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtUsuario_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    strSQL = "SELECT * FROM tbLogin WHERE logUsuario = @parUsuario";
                    comando = new MySqlCommand(strSQL, conexao);
                    comando.Parameters.Clear();
                    comando.Parameters.AddWithValue("@parUsuario", txtUsuario.Text);
                    conexao.Open();
                    // Para retornar mais de uma informação. Caso contrário: comando.ExecuteScalar();
                    dr = comando.ExecuteReader();
                }
                catch (Exception Erro)
                {
                    MessageBox.Show("Erro ==> " + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    if (!dr.HasRows)
                    {
                        txtSenha.ReadOnly = false;
                        txtNomeUsuario.ReadOnly = false;
                        txtUsuario.ReadOnly = true;
                        btnCadastrar.Enabled = true;
                        txtNomeUsuario.Clear();
                        txtSenha.Clear();
                        txtNomeUsuario.Focus();

                        toolStripStatusLabel2.Text = "Digite o Nome do Usuário!";
                    }
                    else
                    {
                        dr.Read();
                        txtNomeUsuario.Text = Convert.ToString(dr["logNomeUsuario"]);
                        txtSenha.Text = Convert.ToString(dr["logSenha"]);

                        toolStripStatusLabel2.Text = "Usuário já cadastrado!";
                    }
                    conexao.Close();
                    comando = null;
                }
            }
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            if (txtNomeUsuario.Text == "")
            {
                MessageBox.Show("O campo Nome de Usuário é obrigatório!!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNomeUsuario.Focus();
                return;
            }
            if (txtSenha.Text == "")
            {
                MessageBox.Show("O campo Senha é obrigatório!!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSenha.Focus();
                return;
            }

            try
            {
                strSQL = "INSERT INTO tbLogin(logUsuario, logSenha, logNomeUsuario, logLastUpdate) values (@parUsuario, @parSenha, @parNomeUsuario, CURRENT_TIMESTAMP)";
                comando = new MySqlCommand(strSQL, conexao);

                comando.Parameters.Clear();
                comando.Parameters.AddWithValue("@parUsuario", txtUsuario.Text);
                comando.Parameters.AddWithValue("@parNomeUsuario", txtNomeUsuario.Text);
                comando.Parameters.AddWithValue("@parSenha", txtSenha.Text);
                conexao.Open();
                // Para retornar mais de uma informação. Caso contrário: comando.ExecuteScalar();
                comando.ExecuteNonQuery();
            }
            catch (Exception Erro)
            {
                MessageBox.Show("Erro ==> " + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                MessageBox.Show("Cadastro efetuado com Sucesso!!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            conexao.Close();
            comando = null;
        }
    }
}
