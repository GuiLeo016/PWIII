﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient; //<-- Inserir

namespace prjMinhaLoja
{
    public partial class frmAltCliente : Form
    {
        // Variáveis de Controle de Conexão

        MySqlConnection conexao;
        MySqlCommand comando;
        MySqlDataAdapter da;
        MySqlDataReader dr;
        string strSQL;

        public frmAltCliente()
        {
            InitializeComponent();
            conexao = new MySqlConnection("Server=localhost;Port=3306;Database=dbLoja;User=root");
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void mtxtRG_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    strSQL = "SELECT * FROM tbClientes WHERE rgCliente = @parRGCliente";
                    comando = new MySqlCommand(strSQL, conexao);
                    comando.Parameters.Clear();
                    comando.Parameters.AddWithValue("@parRGCliente", mtxtRG.Text);
                    conexao.Open();
                    // Para retornar mais de uma informação. Caso contrário: comando.ExecuteScalar();
                    dr = comando.ExecuteReader();
                }
                catch (Exception Erro)
                {
                    MessageBox.Show("Erro ==> " + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    if (!dr.HasRows)
                    {
                        MessageBox.Show("RG não cadastrado", "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        while (dr.Read())
                        {
                            dr.Read();
                            txtNome.Text = Convert.ToString(dr["nomeCliente"]);
                            txtEndereco.Text = Convert.ToString(dr["enderecoCliente"]);
                            txtCidade.Text = Convert.ToString(dr["cidadeCliente"]);
                            cmbUF.SelectedText = Convert.ToString(dr["ufCliente"]);
                            mtxtTelefone.Text = Convert.ToString(dr["telefoneCliente"]);

                            mtxtRG.ReadOnly = true;
                            txtNome.ReadOnly = false;
                            txtEndereco.ReadOnly = false;
                            txtCidade.ReadOnly = false;
                            cmbUF.Enabled = true;
                            mtxtTelefone.ReadOnly = false;
                            btnAlterar.Enabled = true;

                            toolStripStatusLabel2.Text = "Altere os campos desejados!";
                            txtNome.Focus();
                        }
                    }
                    conexao.Close();
                    comando = null;
                }
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (mtxtRG.Text == "" || txtNome.Text == "" || txtEndereco.Text == "" || txtCidade.Text == "" || cmbUF.Text == "" || mtxtTelefone.Text == "")
            {
                MessageBox.Show("Preencha todos os campos!!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                strSQL = "update tbClientes set nomeCliente = @parNome, enderecoCliente = @parEnd, cidadeCliente = @parCidade, ufCliente = @parUF, telefoneCliente = @parTel, ultAtualizacao = current_timestamp where rgCliente = @parRG";
                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.Clear();
                comando.Parameters.AddWithValue("@parRG", mtxtRG.Text);
                comando.Parameters.AddWithValue("@parNome", txtNome.Text);
                comando.Parameters.AddWithValue("@parEnd", txtEndereco.Text);
                comando.Parameters.AddWithValue("@parCidade", txtCidade.Text);
                comando.Parameters.AddWithValue("@parUF", cmbUF.Text);
                comando.Parameters.AddWithValue("@parTel", mtxtTelefone.Text);

                conexao.Open();
                comando.ExecuteNonQuery();
            }
            catch (Exception Erro)
            {
                MessageBox.Show("Erro ==> " + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conexao.Close();
                comando = null;
                return;
            }
            finally
            {
                MessageBox.Show("Alteração efetuada com Sucesso!!", "Alteração", MessageBoxButtons.OK, MessageBoxIcon.Information);

                mtxtRG.Clear();
                txtNome.Clear();
                txtEndereco.Clear();
                txtCidade.Clear();
                cmbUF.Text = "";
                mtxtTelefone.Clear();

                mtxtRG.ReadOnly = false;
                mtxtRG.Focus();
                txtNome.ReadOnly = true;
                txtEndereco.ReadOnly = true;
                txtCidade.ReadOnly = true;
                cmbUF.Enabled = false;
                mtxtTelefone.Clear();
                btnAlterar.Enabled = false;

                toolStripStatusLabel2.Text = "Insira o RG do Cliente <Enter>";
            }
            conexao.Close();
            comando = null;
        }

        private void frmAltCliente_Activated(object sender, EventArgs e)
        {
            mtxtRG.Focus();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mtxtRG.Clear();
            mtxtRG.Focus();
            txtNome.Clear();
            txtEndereco.Clear();
            txtCidade.Clear();
            cmbUF.Text = "";
            mtxtTelefone.Clear();

            mtxtRG.ReadOnly = false;
            txtNome.ReadOnly = true;
            txtEndereco.ReadOnly = true;
            txtCidade.ReadOnly = true;
            cmbUF.Enabled = false;
            mtxtTelefone.Clear();
            btnAlterar.Enabled = false;

            toolStripStatusLabel2.Text = "Insira o RG do Cliente <Enter>";
        }
    }
}
