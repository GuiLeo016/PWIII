﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace prjMinhaLoja
{
    public partial class frmSplash : Form
    {
        public frmSplash()
        {
            InitializeComponent();
        }

        private void timerSplash_Tick(object sender, EventArgs e)
        {
            if (pbSplash.Value < 100) {
                pbSplash.Value += 1;
            } else {
                timerSplash.Enabled = false;
                this.Visible = false;

                frmLogin frmlogin = new frmLogin();
                frmlogin.ShowDialog();

                this.Close();
            }

            if (pbSplash.Value % 15 == 0)
            {
                if (lblCarregando.Text == "Carregando...")
                {
                    lblCarregando.Text = "Carregando.";
                }
                else if (lblCarregando.Text == "Carregando.")
                {
                    lblCarregando.Text = "Carregando..";
                }
                else if (lblCarregando.Text == "Carregando..")
                {
                    lblCarregando.Text = "Carregando...";
                }
            }
        }
    }
}
