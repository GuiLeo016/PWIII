﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient; //<-- Inserir

namespace prjMinhaLoja
{
    public partial class frmCadProd : Form
    {
        // Variáveis de Controle de Conexão

        MySqlConnection conexao;
        MySqlCommand comando;
        MySqlDataAdapter da;
        MySqlDataReader dr;
        string strSQL;

        // Variáves Globais
        decimal vPrcCusto = 0, vMargLucro = 0, vPrcVenda = 0, vEstoqMin = 0, vQtdEstoq = 0;

        public frmCadProd()
        {
            InitializeComponent();
            //Criando a String de Conexão
            conexao = new MySqlConnection("Server=localhost;Port=3306;Database=dbLoja;User=root");
        }

        private void txtCodigo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    strSQL = "SELECT * FROM tbProdutos WHERE cdProduto = @parCdProduto";
                    comando = new MySqlCommand(strSQL, conexao);
                    comando.Parameters.Clear();
                    comando.Parameters.AddWithValue("@parCdProduto", txtCodigo.Text);
                    conexao.Open();
                    // Para retornar mais de uma informação. Caso contrário: comando.ExecuteScalar();
                    dr = comando.ExecuteReader();
                }
                catch (Exception Erro)
                {
                    MessageBox.Show("Erro ==> " + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    if (!dr.HasRows)
                    {
                        txtDescricao.ReadOnly = false;
                        cmbUnidade.Enabled = true;
                        txtLocacao.ReadOnly = false;
                        txtEstoqMin.ReadOnly = false;
                        txtPrcCusto.ReadOnly = false;
                        txtMargLucro.ReadOnly = false;
                        btnCadastrar.Enabled = true;

                        toolStripStatusLabel2.Text = "Insira os dados do produto";
                        txtDescricao.Focus();
                    }
                    else
                    {
                        while (dr.Read())
                        {
                            dr.Read();
                            txtCodigo.ReadOnly = true;
                            txtDescricao.Text = Convert.ToString(dr["descProduto"]);
                            txtQtdEstoq.Text = Convert.ToString(dr["qtdEstoqProduto"]);
                            cmbUnidade.Text = Convert.ToString(dr["unidadeProduto"]);
                            txtLocacao.Text = Convert.ToString(dr["locacaoProduto"]);
                            txtEstoqMin.Text = Convert.ToString(dr["estoqMinProduto"]);
                            txtPrcCusto.Text = Convert.ToString(dr["prcCustoProduto"]);
                            txtMargLucro.Text = Convert.ToString(dr["margLucroProduto"]);

                            toolStripStatusLabel2.Text = "Produto já cadastrado!";

                            vPrcCusto = decimal.Parse(txtPrcCusto.Text);
                            vMargLucro = decimal.Parse(txtMargLucro.Text);
                            vPrcVenda = vPrcCusto + (vPrcCusto * (vMargLucro / 100));

                            txtPrcVenda.Text = vPrcVenda.ToString("C");
                        }
                    }
                    conexao.Close();
                    comando = null;
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtCodigo.Clear();
            txtCodigo.Focus();
            txtDescricao.Clear();
            txtQtdEstoq.Text = "0";
            cmbUnidade.Text = "";
            txtLocacao.Clear();
            txtEstoqMin.Clear();
            txtPrcCusto.Clear();
            txtMargLucro.Clear();
            txtPrcVenda.Text = "0,00";

            txtCodigo.ReadOnly = false;
            txtDescricao.ReadOnly = true;
            cmbUnidade.Enabled = false;
            txtLocacao.ReadOnly = true;
            txtEstoqMin.ReadOnly = true;
            txtPrcCusto.ReadOnly = true;
            txtMargLucro.ReadOnly = true;
            btnCadastrar.Enabled = false;

            toolStripStatusLabel2.Text = "Insira o Código do Produto <Enter>";
        }

        private void frmCadProd_Activated(object sender, EventArgs e)
        {
            txtCodigo.Focus();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            if (txtCodigo.Text == "" || txtDescricao.Text == "" || txtQtdEstoq.Text == "" || txtEstoqMin.Text == "" || cmbUnidade.Text == "" || txtLocacao.Text == "" || txtPrcCusto.Text == "" || txtMargLucro.Text == "")
            {
                MessageBox.Show("Preencha todos os campos!!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                strSQL = "insert into tbProdutos values (@parCd, @parDesc, @parEstoq, @parEstoqMin, @parUnid, @parLoc, @parPrcCusto, @parMargLucro, current_timestamp);";
                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.Clear();
                comando.Parameters.AddWithValue("@parCd", txtCodigo.Text);
                comando.Parameters.AddWithValue("@parDesc", txtDescricao.Text);
                comando.Parameters.AddWithValue("@parEstoq", txtQtdEstoq.Text);
                comando.Parameters.AddWithValue("@parEstoqMin", txtEstoqMin.Text);
                comando.Parameters.AddWithValue("@parUnid", cmbUnidade.Text);
                comando.Parameters.AddWithValue("@parLoc", txtLocacao.Text);
                comando.Parameters.AddWithValue("@parPrcCusto", txtPrcCusto.Text);
                comando.Parameters.AddWithValue("@parMargLucro", txtMargLucro.Text);

                conexao.Open();
                comando.ExecuteNonQuery();
            }
            catch (Exception Erro)
            {
                MessageBox.Show("Erro ==> " + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conexao.Close();
                comando = null;
                return;
            }
            finally
            {
                MessageBox.Show("Cadastro efetuado com Sucesso!!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Information);

                txtCodigo.Clear();
                txtDescricao.Clear();
                txtQtdEstoq.Text = "0";
                cmbUnidade.Text = "";
                txtLocacao.Clear();
                txtEstoqMin.Clear();
                txtPrcCusto.Clear();
                txtMargLucro.Clear();
                txtPrcVenda.Text = "0,00";

                txtCodigo.ReadOnly = false;
                txtCodigo.Focus();
                txtDescricao.ReadOnly = true;
                cmbUnidade.Enabled = false;
                txtLocacao.ReadOnly = true;
                txtEstoqMin.ReadOnly = true;
                txtPrcCusto.ReadOnly = true;
                txtMargLucro.ReadOnly = true;
                btnCadastrar.Enabled = false;

                toolStripStatusLabel2.Text = "Insira o Código do Produto <Enter>";
            }
            conexao.Close();
            comando = null;
        }

        private void txtMargLucro_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                vPrcCusto = decimal.Parse(txtPrcCusto.Text);
                vMargLucro = decimal.Parse(txtMargLucro.Text);
                vPrcVenda = vPrcCusto + (vPrcCusto * (vMargLucro / 100));

                txtPrcVenda.Text = String.Format("{0:C2}", vPrcVenda); // Moeda com duas casas decimais
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtPrcCusto_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                vPrcCusto = decimal.Parse(txtPrcCusto.Text);
                vMargLucro = decimal.Parse(txtMargLucro.Text);
                vPrcVenda = vPrcCusto + (vPrcCusto * (vMargLucro / 100));

                txtPrcVenda.Text = String.Format("{0:C2}", vPrcVenda); // Moeda com duas casas decimais
            }
        }

        private void txtQtdEstoq_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (char)8 && e.KeyChar != (char)44)  //8=backspace,44=virgula,45=Negativo
            {
                e.Handled = true;
            }
        }

        private void txtPrcCusto_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (char)8 && e.KeyChar != (char)44)  //8=backspace,44=virgula,45=Negativo
            {
                e.Handled = true;
            }
        }

        private void txtEstoqMin_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (char)8 && e.KeyChar != (char)44)  //8=backspace,44=virgula,45=Negativo
            {
                e.Handled = true;
            }
        }

        private void txtMargLucro_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (char)8 && e.KeyChar != (char)44)  //8=backspace,44=virgula,45=Negativo
            {
                e.Handled = true;
            }
        }
    }
}
