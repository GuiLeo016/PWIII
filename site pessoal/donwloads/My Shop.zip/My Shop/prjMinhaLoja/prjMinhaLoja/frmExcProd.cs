﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient; //<-- Inserir

namespace prjMinhaLoja
{
    public partial class frmExcProd : Form
    {
        // Variáveis de Controle de Conexão

        MySqlConnection conexao;
        MySqlCommand comando;
        MySqlDataAdapter da;
        MySqlDataReader dr;
        string strSQL;

        // Variáves Globais
        decimal vPrcCusto = 0, vMargLucro = 0, vPrcVenda = 0, vEstoqMin = 0, vQtdEstoq = 0;
        public frmExcProd()

        {
            InitializeComponent();
            //Criando a String de Conexão
            conexao = new MySqlConnection("Server=localhost;Port=3306;Database=dbLoja;User=root");
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtCodigo.Clear();
            txtCodigo.ReadOnly = false;
            txtCodigo.Focus();
            txtDescricao.Clear();
            txtQtdEstoq.Text = "0";
            cmbUnidade.Text = "";
            txtLocacao.Clear();
            txtEstoqMin.Clear();
            txtPrcCusto.Clear();
            txtMargLucro.Clear();
            txtPrcVenda.Text = "0,00";

            btnExcluir.Enabled = false;
            toolStripStatusLabel2.Text = "Insira o Código do Produto <Enter>";
        }

        private void txtCodigo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    strSQL = "SELECT * FROM tbProdutos WHERE cdProduto = @parCdProduto";
                    comando = new MySqlCommand(strSQL, conexao);
                    comando.Parameters.Clear();
                    comando.Parameters.AddWithValue("@parCdProduto", txtCodigo.Text);
                    conexao.Open();
                    // Para retornar mais de uma informação. Caso contrário: comando.ExecuteScalar();
                    dr = comando.ExecuteReader();
                }
                catch (Exception Erro)
                {
                    MessageBox.Show("Erro ==> " + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    if (!dr.HasRows)
                    {
                        MessageBox.Show("Código do Produto Inexistente!!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        while (dr.Read())
                        {
                            dr.Read();
                            txtCodigo.ReadOnly = true;
                            txtDescricao.Text = Convert.ToString(dr["descProduto"]);
                            txtQtdEstoq.Text = Convert.ToString(dr["qtdEstoqProduto"]);
                            cmbUnidade.Text = Convert.ToString(dr["unidadeProduto"]);
                            txtLocacao.Text = Convert.ToString(dr["locacaoProduto"]);
                            txtEstoqMin.Text = Convert.ToString(dr["estoqMinProduto"]);
                            txtPrcCusto.Text = Convert.ToString(dr["prcCustoProduto"]);
                            txtMargLucro.Text = Convert.ToString(dr["margLucroProduto"]);

                            toolStripStatusLabel2.Text = "Confirme os dados do produto a ser excluído!";

                            vPrcCusto = decimal.Parse(txtPrcCusto.Text);
                            vMargLucro = decimal.Parse(txtMargLucro.Text);
                            vPrcVenda = vPrcCusto + (vPrcCusto * (vMargLucro / 100));

                            txtPrcVenda.Text = vPrcVenda.ToString("C");

                            btnExcluir.Enabled = true;
                            toolStripStatusLabel2.Text = "Insira o Código do Produto <Enter>";
                        }
                    }
                    conexao.Close();
                    comando = null;
                }
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                strSQL = "delete from tbProdutos where cdProduto = @parCd;";
                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.Clear();
                comando.Parameters.AddWithValue("@parCd", txtCodigo.Text);

                conexao.Open();
                comando.ExecuteNonQuery();
            }
            catch (Exception Erro)
            {
                MessageBox.Show("Erro ==> " + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conexao.Close();
                comando = null;
                return;
            }
            finally
            {
                MessageBox.Show("Exclusão efetuada com Sucesso!!", "Exclusão", MessageBoxButtons.OK, MessageBoxIcon.Information);

                txtCodigo.Clear();
                txtDescricao.Clear();
                txtQtdEstoq.Text = "0";
                cmbUnidade.Text = "";
                txtLocacao.Clear();
                txtEstoqMin.Clear();
                txtPrcCusto.Clear();
                txtMargLucro.Clear();
                txtPrcVenda.Text = "0,00";

                btnExcluir.Enabled = false;
                txtCodigo.ReadOnly = false;
                txtCodigo.Focus();
                toolStripStatusLabel2.Text = "Insira o Código do Produto <Enter>";
            }
            conexao.Close();
            comando = null;
        }

        private void frmExcProd_Activated(object sender, EventArgs e)
        {
            txtCodigo.Focus();
        }
    }
}
