﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjMinhaLoja
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void cadastrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCadProd objFCadProd = new frmCadProd();
            objFCadProd.MdiParent = this;
            objFCadProd.Show();
        }

        private void alterarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAltProd objFAltProd = new frmAltProd();
            objFAltProd.MdiParent = this;
            objFAltProd.Show();
        }

        private void excluirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExcProd objFExcProd = new frmExcProd();
            objFExcProd.MdiParent = this;
            objFExcProd.Show();
        }

        private void cadastrarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmCadCliente objFCadCliente = new frmCadCliente();
            objFCadCliente.MdiParent = this;
            objFCadCliente.Show();
        }

        private void alterarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmAltCliente objFAltCliente = new frmAltCliente();
            objFAltCliente.MdiParent = this;
            objFAltCliente.Show();
        }

        private void excluirToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmExcCliente objFExcCliente = new frmExcCliente();
            objFExcCliente.MdiParent = this;
            objFExcCliente.Show();
        }

        private void produtosToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmConsProd objFConsProd = new frmConsProd();
            objFConsProd.MdiParent = this;
            objFConsProd.Show();
        }
    }
}
