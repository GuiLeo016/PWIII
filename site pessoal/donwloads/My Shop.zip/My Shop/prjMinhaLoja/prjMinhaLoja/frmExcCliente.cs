﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient; //<-- Inserir

namespace prjMinhaLoja
{
    public partial class frmExcCliente : Form
    {
        // Variáveis de Controle de Conexão

        MySqlConnection conexao;
        MySqlCommand comando;
        MySqlDataAdapter da;
        MySqlDataReader dr;
        string strSQL;

        public frmExcCliente()
        {
            InitializeComponent();
            conexao = new MySqlConnection("Server=localhost;Port=3306;Database=dbLoja;User=root");
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mtxtRG.Clear();
            mtxtRG.Focus();
            txtNome.Clear();
            txtEndereco.Clear();
            txtCidade.Clear();
            cmbUF.Text = "";
            mtxtTelefone.Clear();
            btnExcluir.Enabled = false;
            mtxtRG.ReadOnly = false;

            toolStripStatusLabel2.Text = "Insira o RG do Cliente <Enter>";
        }

        private void frmExcCliente_Activated(object sender, EventArgs e)
        {
            mtxtRG.Focus();
        }

        private void mtxtRG_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    strSQL = "SELECT * FROM tbClientes WHERE rgCliente = @parRGCliente";
                    comando = new MySqlCommand(strSQL, conexao);
                    comando.Parameters.Clear();
                    comando.Parameters.AddWithValue("@parRGCliente", mtxtRG.Text);
                    conexao.Open();
                    // Para retornar mais de uma informação. Caso contrário: comando.ExecuteScalar();
                    dr = comando.ExecuteReader();
                }
                catch (Exception Erro)
                {
                    MessageBox.Show("Erro ==> " + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    if (!dr.HasRows)
                    {
                        MessageBox.Show("RG não cadastrado", "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        while (dr.Read())
                        {
                            dr.Read();
                            txtNome.Text = Convert.ToString(dr["nomeCliente"]);
                            txtEndereco.Text = Convert.ToString(dr["enderecoCliente"]);
                            txtCidade.Text = Convert.ToString(dr["cidadeCliente"]);
                            cmbUF.SelectedText = Convert.ToString(dr["ufCliente"]);
                            mtxtTelefone.Text = Convert.ToString(dr["telefoneCliente"]);
                            btnExcluir.Enabled = true;
                            mtxtRG.ReadOnly = true;

                            toolStripStatusLabel2.Text = "Confira os campos do cliente a ser excluído!";
                        }
                    }
                    conexao.Close();
                    comando = null;
                }
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                strSQL = "delete from tbClientes where rgCliente = @parRG;";
                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.Clear();
                comando.Parameters.AddWithValue("@parRG", mtxtRG.Text);

                conexao.Open();
                comando.ExecuteNonQuery();
            }
            catch (Exception Erro)
            {
                MessageBox.Show("Erro ==> " + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conexao.Close();
                comando = null;
                return;
            }
            finally
            {
                MessageBox.Show("Exclusão efetuada com Sucesso!!", "Exclusão", MessageBoxButtons.OK, MessageBoxIcon.Information);

                mtxtRG.Clear();
                mtxtRG.Focus();
                txtNome.Clear();
                txtEndereco.Clear();
                txtCidade.Clear();
                cmbUF.Text = "";
                mtxtTelefone.Clear();
                btnExcluir.Enabled = false;

                toolStripStatusLabel2.Text = "Insira o RG do Cliente <Enter>";
            }
            conexao.Close();
            comando = null;
        }
    }
}
