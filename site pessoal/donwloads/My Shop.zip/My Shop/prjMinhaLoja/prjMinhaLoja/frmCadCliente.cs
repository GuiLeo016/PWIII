﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient; //<-- Inserir

namespace prjMinhaLoja
{
    public partial class frmCadCliente : Form
    {
        // Variáveis de Controle de Conexão

        MySqlConnection conexao;
        MySqlCommand comando;
        MySqlDataAdapter da;
        MySqlDataReader dr;
        string strSQL;

        public frmCadCliente()
        {
            InitializeComponent();
            //Criando a String de Conexão
            conexao = new MySqlConnection("Server=localhost;Port=3306;Database=dbLoja;User=root");
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mtxtRG.Clear();
            mtxtRG.Focus();
            txtNome.Clear();
            txtEndereco.Clear();
            txtCidade.Clear();
            cmbUF.Text = "";
            mtxtTelefone.Clear();

            mtxtRG.ReadOnly = false;
            txtNome.ReadOnly = true;
            txtEndereco.ReadOnly = true;
            txtCidade.ReadOnly = true;
            cmbUF.Enabled = false;
            mtxtTelefone.Clear();
            btnCadastrar.Enabled = false;

            toolStripStatusLabel2.Text = "Insira o RG do Cliente <Enter>";
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            if (mtxtRG.Text == "" || txtNome.Text == "" || txtEndereco.Text == "" || txtCidade.Text == "" || cmbUF.Text == "" || mtxtTelefone.Text == "")
            {
                MessageBox.Show("Preencha todos os campos!!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                strSQL = "insert into tbClientes values (@parRG, @parNome, @parEnd, @parCidade, @parUF, @parTel, current_timestamp);";
                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.Clear();
                comando.Parameters.AddWithValue("@parRG", mtxtRG.Text);
                comando.Parameters.AddWithValue("@parNome", txtNome.Text);
                comando.Parameters.AddWithValue("@parEnd", txtEndereco.Text);
                comando.Parameters.AddWithValue("@parCidade", txtCidade.Text);
                comando.Parameters.AddWithValue("@parUF", cmbUF.Text);
                comando.Parameters.AddWithValue("@parTel", mtxtTelefone.Text);

                conexao.Open();
                comando.ExecuteNonQuery();
            }
            catch (Exception Erro)
            {
                MessageBox.Show("Erro ==> " + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conexao.Close();
                comando = null;
                return;
            }
            finally
            {
                MessageBox.Show("Cadastro efetuado com Sucesso!!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Information);

                mtxtRG.Clear();
                txtNome.Clear();
                txtEndereco.Clear();
                txtCidade.Clear();
                cmbUF.Text = "";
                mtxtTelefone.Clear();

                mtxtRG.ReadOnly = false;
                mtxtRG.Focus();
                txtNome.ReadOnly = true;
                txtEndereco.ReadOnly = true;
                txtCidade.ReadOnly = true;
                cmbUF.Enabled = false;
                mtxtTelefone.Clear();
                btnCadastrar.Enabled = false;

                toolStripStatusLabel2.Text = "Insira o RG do Cliente <Enter>";
            }
            conexao.Close();
            comando = null;

        }

        private void mtxtRG_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    strSQL = "SELECT * FROM tbClientes WHERE rgCliente = @parRGCliente";
                    comando = new MySqlCommand(strSQL, conexao);
                    comando.Parameters.Clear();
                    comando.Parameters.AddWithValue("@parRGCliente", mtxtRG.Text);
                    conexao.Open();
                    // Para retornar mais de uma informação. Caso contrário: comando.ExecuteScalar();
                    dr = comando.ExecuteReader();
                }
                catch (Exception Erro)
                {
                    MessageBox.Show("Erro ==> " + Erro.Message, "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    if (!dr.HasRows)
                    {
                        mtxtRG.ReadOnly = true;
                        txtNome.ReadOnly = false;
                        txtEndereco.ReadOnly = false;
                        txtCidade.ReadOnly = false;
                        cmbUF.Enabled = true;
                        mtxtTelefone.ReadOnly = false;
                        btnCadastrar.Enabled = true;

                        toolStripStatusLabel2.Text = "Insira os dados do Cliente";
                        txtNome.Focus();
                    }
                    else
                    {
                        while (dr.Read())
                        {
                            dr.Read();
                            mtxtRG.ReadOnly = true;
                            txtNome.Text = Convert.ToString(dr["nomeCliente"]);
                            txtEndereco.Text = Convert.ToString(dr["enderecoCliente"]);
                            txtCidade.Text = Convert.ToString(dr["cidadeCliente"]);
                            cmbUF.SelectedText = Convert.ToString(dr["ufCliente"]);
                            mtxtTelefone.Text = Convert.ToString(dr["telefoneCliente"]);

                            toolStripStatusLabel2.Text = "Cliente já cadastrado!";
                        }
                    }
                    conexao.Close();
                    comando = null;
                }
            }
        }
    }
}
